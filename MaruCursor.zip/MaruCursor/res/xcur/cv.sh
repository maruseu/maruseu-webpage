#!/bin/sh
fname=${1%.*}
xcursorgen $1 $fname
